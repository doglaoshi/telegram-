#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Telegram 管理机器人
功能：群成员发送"1"时自动给予管理员权限
"""

import logging
import os
from telegram import Update, ChatMember
from telegram.ext import Application, MessageHandler, filters, ContextTypes
from telegram.error import TelegramError
import json
from datetime import datetime

# 配置日志
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler('bot.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# 从配置文件读取token
def load_config():
    """加载配置文件"""
    try:
        with open('config.json', 'r', encoding='utf-8') as f:
            config = json.load(f)
        return config
    except FileNotFoundError:
        logger.error("配置文件 config.json 不存在，请创建配置文件")
        return None
    except json.JSONDecodeError:
        logger.error("配置文件格式错误")
        return None

class AdminBot:
    def __init__(self, token):
        self.token = token
        self.application = Application.builder().token(token).build()
        self.setup_handlers()
        
    def setup_handlers(self):
        """设置消息处理器"""
        # 监听所有文本消息
        message_handler = MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message)
        self.application.add_handler(message_handler)
        
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """处理收到的消息"""
        try:
            # 检查是否是群聊
            if update.effective_chat.type not in ['group', 'supergroup']:
                return
                
            # 检查消息内容是否为"1"
            if update.message.text.strip() != "1":
                return
                
            user = update.effective_user
            chat = update.effective_chat
            
            logger.info(f"用户 {user.full_name} (ID: {user.id}) 在群 {chat.title} (ID: {chat.id}) 中发送了 '1'")
            
            # 检查机器人是否是管理员
            bot_member = await context.bot.get_chat_member(chat.id, context.bot.id)
            if bot_member.status != ChatMember.ADMINISTRATOR:
                await update.message.reply_text("❌ 机器人需要管理员权限才能提升其他用户为管理员")
                logger.warning(f"机器人在群 {chat.title} 中没有管理员权限")
                return
                
            # 检查机器人是否有提升管理员的权限
            if not bot_member.can_promote_members:
                await update.message.reply_text("❌ 机器人没有提升管理员的权限")
                logger.warning(f"机器人在群 {chat.title} 中没有提升管理员的权限")
                return
            
            # 检查用户当前状态
            user_member = await context.bot.get_chat_member(chat.id, user.id)
            
            # 如果用户已经是管理员或创建者，则不需要操作
            if user_member.status in [ChatMember.ADMINISTRATOR, ChatMember.OWNER]:
                await update.message.reply_text(f"✅ @{user.username or user.full_name} 已经是管理员了！")
                return
            
            # 提升用户为管理员
            await context.bot.promote_chat_member(
                chat_id=chat.id,
                user_id=user.id,
                can_delete_messages=True,
                can_restrict_members=True,
                can_pin_messages=True,
                can_promote_members=False,  # 不给予提升其他人的权限，避免滥用
                can_change_info=True,
                can_invite_users=True,
                can_manage_chat=True,
                can_manage_video_chats=True
            )
            
            # 发送确认消息
            success_message = f"🎉 恭喜 @{user.username or user.full_name} 成为管理员！"
            await update.message.reply_text(success_message)
            
            # 记录日志
            logger.info(f"成功将用户 {user.full_name} (ID: {user.id}) 提升为群 {chat.title} 的管理员")
            
            # 记录到文件
            self.log_promotion(user, chat)
            
        except TelegramError as e:
            error_message = f"❌ 操作失败: {str(e)}"
            await update.message.reply_text(error_message)
            logger.error(f"Telegram API 错误: {e}")
            
        except Exception as e:
            await update.message.reply_text("❌ 发生未知错误，请稍后再试")
            logger.error(f"处理消息时发生错误: {e}")
    
    def log_promotion(self, user, chat):
        """记录提升管理员的操作到文件"""
        try:
            log_entry = {
                "timestamp": datetime.now().isoformat(),
                "user_id": user.id,
                "username": user.username,
                "full_name": user.full_name,
                "chat_id": chat.id,
                "chat_title": chat.title
            }
            
            # 读取现有日志
            promotions_file = "promotions.json"
            promotions = []
            
            if os.path.exists(promotions_file):
                with open(promotions_file, 'r', encoding='utf-8') as f:
                    promotions = json.load(f)
            
            # 添加新记录
            promotions.append(log_entry)
            
            # 保存到文件
            with open(promotions_file, 'w', encoding='utf-8') as f:
                json.dump(promotions, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            logger.error(f"记录提升日志时发生错误: {e}")
    
    def run(self):
        """启动机器人"""
        logger.info("机器人启动中...")
        self.application.run_polling(allowed_updates=Update.ALL_TYPES)

def main():
    """主函数"""
    # 加载配置
    config = load_config()
    if not config:
        print("请先配置 config.json 文件")
        return
    
    token = config.get('bot_token')
    if not token:
        print("配置文件中缺少 bot_token")
        return
    
    # 创建并启动机器人
    bot = AdminBot(token)
    
    try:
        bot.run()
    except KeyboardInterrupt:
        logger.info("机器人已停止")
    except Exception as e:
        logger.error(f"机器人运行时发生错误: {e}")

if __name__ == '__main__':
    main()
