#!/bin/bash

# Telegram 管理机器人启动脚本

echo "🤖 启动 Telegram 管理机器人..."

# 检查配置文件是否存在
if [ ! -f "config.json" ]; then
    echo "❌ 配置文件 config.json 不存在!"
    echo "请先复制 config.json.example 为 config.json 并填入你的机器人 token"
    echo "cp config.json.example config.json"
    exit 1
fi

# 检查依赖是否安装
if ! python3 -c "import telegram" 2>/dev/null; then
    echo "📦 安装依赖包..."
    pip3 install -r requirements.txt
fi

# 启动机器人
echo "🚀 启动机器人..."
python3 bot.py
